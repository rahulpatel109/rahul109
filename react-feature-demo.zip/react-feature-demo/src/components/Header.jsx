import React from 'react';

const Header = () => {
  return (
    <header style={{ textAlign: 'center', padding: '20px', background: '#f0f0f0' }}>
      <h1>🚀 React Feature Demo</h1>
    </header>
  );
};

export default Header;