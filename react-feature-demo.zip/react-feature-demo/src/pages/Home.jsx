import React, { useState } from 'react';
import Button from '../components/Button';

const Home = () => {
  const [count, setCount] = useState(0);

  return (
    <div style={{ textAlign: 'center' }}>
      <h2>🏠 Home</h2>
      <p>Count: {count}</p>
      <Button label="Increment" onClick={() => setCount(count + 1)} />
      <Button label="Decrement" onClick={() => setCount(count - 1)} />
    </div>
  );
};

export default Home;