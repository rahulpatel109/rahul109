import React from 'react';

const About = () => {
  return (
    <div style={{ textAlign: 'center' }}>
      <h2>📘 About</h2>
      <p>This app showcases core React features like JSX, Components, Hooks, and Routing.</p>
    </div>
  );
};

export default About;