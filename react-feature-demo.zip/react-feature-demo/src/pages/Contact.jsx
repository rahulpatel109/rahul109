import React, { useEffect } from 'react';

const Contact = () => {
  useEffect(() => {
    console.log('📞 Contact Page Loaded');
  }, []);

  return (
    <div style={{ textAlign: 'center' }}>
      <h2>📞 Contact</h2>
      <p>Email us at: contact@reactdemo.com</p>
    </div>
  );
};

export default Contact;