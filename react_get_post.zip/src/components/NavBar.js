import React from 'react'
import ToggleButton from './ToggleButton'

const NavBar = () => {
  return (
    <div>
        NavBar
        <ToggleButton/>
    </div>
  )
}

export default NavBar