import React from 'react'

const ChildA = ({count}) => {
  return (
    <div>
        <h2>Count is:{count}</h2>
    </div>
  )
}

export default ChildA