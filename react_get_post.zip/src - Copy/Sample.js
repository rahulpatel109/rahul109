import React from 'react'

const Sample = () => {
  return (
    <div>Sample Componet</div>
  )
}

export default Sample